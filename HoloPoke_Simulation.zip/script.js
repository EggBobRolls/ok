
// Setting up the scene, camera, and renderer
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Adding light to the scene
const light = new THREE.PointLight(0xffffff, 1, 100);
light.position.set(10, 10, 10);
scene.add(light);

// Creating a basic sphere to represent the Poké Ball
const geometry = new THREE.SphereGeometry(1, 32, 32);
const material = new THREE.MeshStandardMaterial({ color: 0xff0000 });
const pokeball = new THREE.Mesh(geometry, material);
scene.add(pokeball);

// Adding rotation animation
let rotationSpeed = 0.01;
function animate() {
    requestAnimationFrame(animate);
    pokeball.rotation.y += rotationSpeed;
    renderer.render(scene, camera);
}

// Adjusting the camera position
camera.position.z = 5;

// Click event to simulate throwing the ball
document.addEventListener("click", () => {
    rotationSpeed = 0.05;
    setTimeout(() => {
        rotationSpeed = 0.01; // Reset speed after "throw"
    }, 1000);
});

animate();
